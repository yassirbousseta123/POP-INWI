"""Altair schema wrappers."""

# ruff: noqa: F403
from .v5.schema import *
